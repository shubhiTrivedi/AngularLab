import { Pipe, PipeTransform } from '@angular/core';
import { Book } from './book/book';

@Pipe({
  name: "bookFilter"
})
export class BookFilterPipe implements PipeTransform {

  transform(value: Book[],titleSearch:string,authorSearch:string, yearSearch:number,idSearch){

    let filters: string[] = [];
    let titleFilter: string = titleSearch ? titleSearch.toLocaleLowerCase() : null;
    let authorFilter: string = authorSearch ? authorSearch.toLocaleLowerCase() : null;
    let yearFilter: string = yearSearch ? yearSearch.toString() :  null;
    let idFilter: string = idSearch ? idSearch.toString() :  null;

    if(titleFilter) {
      value = value.filter((book: Book) => book.title.toLocaleLowerCase().indexOf(titleFilter) != -1)
    }

    if(authorFilter) {
      value = value.filter((book: Book) => book.author.toLocaleLowerCase().indexOf(authorFilter) != -1)
    }

    if(yearFilter) {
      value = value.filter((book: Book) => book.year.toString().indexOf(yearFilter) != -1);
    }

    if(idFilter) { 
      value = value.filter((book: Book) => book.id.toString().indexOf(idFilter) != -1);
    }
    return value;
  }

}
